

![Typing SVG](https://readme-typing-svg.demolab.com?font=Ribeye&size=50&pause=1000&color=3F00FF&center=true&width=900&height=100&lines=𝐍𝐄𝐗𝐔𝐒%20-𝐗𝐌𝐃;%20𝗠𝗨𝗟𝗧𝗜-𝗗𝗘𝗩𝗜𝗖𝗘%20𝗪𝗛𝗔𝗧𝗦𝗔𝗣𝗣%20𝗕𝗢𝗧;%20𝗗𝗘𝗩𝗘𝗟𝗢𝗣𝗘𝗗%20𝗕𝗬%20𝐌𝐀𝐋𝐕𝐈𝐍%20𝐊𝐈𝐍𝐆..💖)
<p align="center">

</p>


<div align="center"> 
  <a href="https://youtube.com/@malvintech2"> 
    <img src="https://files.catbox.moe/ex1627.jpg" alt="JINWOO BOT" height="200"> 
  </a> 
</div>
  </a>


<br>

   </p>
<p align="center">
<a href="https://github.com/kingmalvn"><img title="Author" src="https://img.shields.io/badge/Malvin King-blue?style=for-the-badge&logo=Github"></a> <a href="https://youtube.com/@malvintech2"><img title="Author" src="https://img.shields.io/badge/YT CHANNEL-darkred?style=for-the-badge&logo=youtube"></a> <a href="https://wa.me/263714757857"><img title="Author" src="https://img.shields.io/badge/Contact Me-darkgreen?style=for-the-badge&logo=whatsapp"></a>
<p/> 

 <p align="center">
<a href="https://github.com/kingmalvn/followers"><img title="Followers" src="https://img.shields.io/github/followers/kingmalvn?color=purple&style=flat-square"></a>
<a href="https://github.com/kingmalvn/JINWOO-BOT/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/kingmalvn/JINWOO-BOT?color=blue&style=flat-square"></a>
<a href="https://github.com/kingmalvn/JINWOO-BOT/network/members"><img title="Forks" src="https://img.shields.io/github/forks/kingmalvn/JINWOO-BOT?color=blue&style=flat-square"></a>
<a href="https://github.com/kingmalvn/JINWOO-BOT/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/kingmalvn/JINWOO-BOT?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://github.com/kingmalvn/JINWOO-BOT/"><img title="Size" src="https://img.shields.io/github/repo-size/kingmalvn/JINWOO-BOT?style=flat-square&color=green"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Fkingmalvn%2FJINWOO-BOT&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2300FF6D&title=hits&edge_flat=false"/></a>
<a href="https://github.com/kingmalvn/JINWOO-BOT/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>&nbsp;&nbsp;</a>
<p align="center"><img src="https://profile-counter.glitch.me/{JINWOO-BOT}/count.svg" alt="kingmalvn :: Visitor's Count" old_src="https://profile-counter.glitch.me/{kingmalvn}/count.svg" /></p>
<p align="center">
<a href="https://github.com/kingmalvn/JINWOO"BOT"><img title="PUBLIC-BOT" src="https://img.shields.io/static/v1?label=Language&message=English&style=flat-square&color=darkpink"></a> &nbsp;
  <img src="https://komarev.com/ghpvc/?username=JINWOO-BOT&label=VIEWS&style=flat-square&color=blue" />
</a>
<p align="center">
  <a href="https://github.com/kingmalvn/JINWOO-BOT"><img title="Release" src="https://img.shields.io/badge/Release-beta%20v3.0-darkcyan.svg?style=for-the-badge&logo=appveyor" /></a>

<p align='center'>
    </p>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

## 🛠️ `JINBOT INSTALATION`



1. Fork and star this repo first

Click the button below to fork the JIN Bot repository to your GitHub account:

  <br>
    <p align="left">
<a href='https://github.com/kingmalvn/JINWOO-BOT/fork' target="_blank"><img alt='Fork Repo' src='https://img.shields.io/badge/Fork Repo-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=orange&color=darkgreen'/></a>

2. GET SESSION
    <br>
    <p align="left">
<a href='https://jinwoo-pair-7a2966e4757b.herokuapp.com/pair' target="_blank"><img alt='REQUEST PAIR CODE' src='https://img.shields.io/badge/Pair_code-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=darkorange&color=darkorange'/></a>

3. GET CREDS.JSON FILE

<div align="left">
  <a href="https://replit.com/@malvink003/JINWOO-PAIR?v=1">
    <img src="https://img.shields.io/badge/GET%20PAIR%20CODE-Replit-success?style=for-the-badge" alt="Deploy on Replit"/>
  </a>
</div>

### After getting creds.json file, upload it to session folder

## `DEPLOYMENTS`
  
[![Deploy to Heroku](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/kingmalvn/JINWOO-BOT)

💯 safe
    

[![Deploy on Repl.it](https://repl.it/badge/github/quiec/whatsAlfa)](https://repl.it/github/kingmalvn/JINWOO-BOT)


<p align="left">
    <a href="https://app.koyeb.com/apps/deploy?type=git&repository=github.com%2Fkingmalvn%2FJINWOO-BOT&branch=main&name=JINWOO-BOT&builder=dockerfile&env[DATABASE_URL]=&env[SESSION_ID]=Enter+your+session+id+here&env[AUTO_STATUS_SEEN]=true&env=[AUTO_REACT_STATUS]=true&env[OWNER_NUMBER]=Enter+your+number&env[OWNER_NAME]=Enter+your+name&env[TIMEZONE]=Africa/Nairobi">
        <img src="https://www.koyeb.com/static/images/deploy/button.svg" height="40"/>
    </a>
</p>



<details>
<summary>𝘋𝘌𝘗𝘓𝘖𝘠 𝘛𝘖 𝘏𝘌𝘙𝘖𝘒𝘜, 𝘔𝘌𝘛𝘏𝘖𝘋 2</summary>
 
* `Fork` JINWOO Repository or `sync` if you had forked.
* `Link` to your WhatsApp using Server 1, 2 or 3
* Incase you use Server 2, paste the session id on settings.js @SESSION_ID
* If you used Server 3, upload the `creds.json` received in the `session` folder.
* Alternatively; you can open the `creds.json` using `Mt manager` or `treb edit` and copy everything and paste at `creds.json` on the `session` folder.
* Go to `src>data>role>owner.json` and enter your number.
* Edit your details at `settings.js` (Optional).
* Create an `heroku` account if you don't have.
* Then choose create new app
* Enter your app name and Create.
* Connect with your GitHub account.
* Search JINWOO-BOT, and connect.
* Press deploy and wait for a few minutes.
* Enjoy.
</details>

<details>
<summary>𝘔𝘖𝘙𝘌 𝘋𝘌𝘗𝘓𝘖𝘠𝘔𝘌𝘕𝘛𝘚</summary>
 
<p align="center">
  <a href="https://dashboard.render.com/select-repo?type=web"><img src="https://img.shields.io/badge/render-333333?style=for-the-badge&logo=render&logoColor=FFFFFF"></a>
  <p align="center">
  <a href="https://account.solarhosting.cc/register?ref=6JR38R0T"><img src="https://img.shields.io/badge/solar hosting-000000?style=for-the-badge&logo=solar hosting&logoColor=FFA500"></a>
  <p align="center">
  <a href="https://bot-hosting.net/?aff=1231885228566646795"><img src="https://img.shields.io/badge/bot hosting-000000?style=for-the-badge&logo=bot hosting &logoColor=FFA500"></a>
   <p align="center">
   <a href="https://dashboard.katabump.com/auth/login#5db6cb" target="_blank">
  <img src="https://img.shields.io/badge/Katabump-D6B7D6?style=for-the-badge&logo=server&logoColor=black" alt="Katabump"/></a>
  <p align="center"
  <a href="https://pella.app" target="_blank">
  <img src="https://img.shields.io/badge/Pella_App-16A085?style=for-the-badge&logo=server&logoColor=white" alt="Pella App"/></a>
  <p align="center" 
  <a href="https://daki.cc" target="_blank">
  <img src="https://img.shields.io/badge/Daki_CC-34495E?style=for-the-badge&logo=server&logoColor=white" alt="Daki CC"/>
</a>

</details>


<details>
<summary>𝘏𝘖𝘞 𝘛𝘖 𝘋𝘌𝘗𝘓𝘖𝘠 𝘖𝘕 𝘗𝘈𝘕𝘌𝘓𝘚</summary>
 
1. `Fork` the Repository.
2. If already forked then `sync` fork repository.
3. Click on the green `Code` button and click `download as zip`.
4. `Upload` the script zip file to your `panel`.
5. `Unarchieve` the uploaded zip file.
6. Open the `unarchieved folder` and `move` all files to container by typing (`../`)
7. Now go to `console` and `start` bot.
8. Wait for `5-10 mins` to enter your number.
9. Enter your number when requested to get the pair code.
10. Enter pair code in link devices in whatsapp.
11. Deployment successful.
</details>
 

<details>
<summary>𝘔𝘈𝘕𝘜𝘈𝘓 𝘐𝘕𝘚𝘛𝘈𝘓𝘓𝘔𝘌𝘕𝘛𝘚</summary>
  
## `REQUIREMENTS`
* [Node.js](https://nodejs.org/en/)
* [Git](https://git-scm.com/downloads)
* [FFmpeg](https://github.com/BtbN/FFmpeg-Builds/releases/download/autobuild-2020-12-08-13-03/ffmpeg-n4.3.1-26-gca55240b8c-win64-gpl-4.3.zip)
* [Libwebp](https://developers.google.com/speed/webp/download)
* Any text editor
  
## `CLONE REPO & INSTALLATION DEPENDENCIES`
```bash
git clone https://github.com/<your gitHub Username>/JINWOO-BOT.git
cd JINWOO-BOT
npm start
```

## `FOR SSH/UBUNTU/LINUX`
```bash
sudo apt-get update
sudo apt-get upgrade -y
sudo apt-get install -y bash
sudo apt-get install -y libwebp
sudo apt-get install -y git
sudo apt-get install -y nodejs
sudo apt-get install -y ffmpeg
sudo apt-get install -y wget
sudo apt-get install -y imagemagick
git clone https://github.com/<your-gitHub-Username>/JINWOO-BOT
cd JINWOO-BOT
npm install
npm start
```

## `FOR TERMUX`
```bash
apt update -y && apt upgrade -y && pkg update -y && pkg upgrade -y && pkg install bash -y && pkg install libwebp -y && pkg install git -y && pkg install nodejs -y && pkg install ffmpeg -y && pkg install wget -y && pkg install imagemagick -y && pkg install yarn && termux-setup-storage
cd /sdcard
cd bot folder name
yarn install
npm start
```

## `FOR 24/7 ACTIVATION PM2 (TERMUX)`
```bash
npm i -g pm2 && pm2 start index.js && pm2 save && pm2 logs
```

## `FOR 24/7 ACTIVATION RE-EXECUTION PM2 (TERMUX)`
```bash
npm i -g pm2 && pm2 start index.js -f && pm2 save && pm2 logs
```
</details>


</p>

##
* Need help? please create an <a href="https://github.com/kingmalvn/JINWOO-BOT/issues">issue</a></p>

##
- Star ⭐ this repository if you like Jinwoo Bot.
- If any problem, then [`Whatsapp Me Here`](https://wa.me/263714757857)

##
<h2 align="center">  𝗣𝗢𝗟𝗜𝗧𝗘 𝗡𝗢𝗧𝗜𝗖𝗘!
</h2>

- *`JINWOO BOT` is not affiliated with `WhatsApp Inc`.*
- *Misusing the bot may result in account banning.*
- *Use at your own risk.*

##
 [ JINWOO WHATSAPP CHANNEL ](https://whatsapp.com/channel/0029Vac8SosLY6d7CAFndv3Z)


**© Jinwoo Bot**
##
![MIT License](https://img.shields.io/badge/License-green.svg)
